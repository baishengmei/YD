import React from 'react'
import ReactDOM from 'react-dom'
import Mockserver from './index'

ReactDOM.render(
	<Mockserver />,
	document.getElementById("app")
);
