import React, { Component, PropTypes } from 'react'
import ReactDOM from 'react-dom'
// import AppBar from 'material-ui/AppBar';

class mockHeader extends Component {
	constructor(props){
		super(props)
	}
  	render() {
	  	return (
	  		<div>
				<div>Header</div>
			</div>
  		)
  	}
}

export { mockHeader };