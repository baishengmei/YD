## YADK （全称 Youdao Advertisement Development Kit）

原生广告已是主流/趋势，我们已经有 Android 和 iOS 的 native SDK，so ...，YADK 是针对 web 而定制的（这里的 web 包含移动设备的浏览器 + webview 和 PC 浏览器），其目标是：
- 为广告应用开发者提供一组 API 集合，并定义这些 API 的参数和返回值；
- 这些 API 可满足：广告数据的获取，成功展示后的通知，超链接点击的监控等常规需求；
- 使得广告应用开发者基于这些 API，可开发出符合自己产品风格的广告 。

> 实际应用中使用小写，如 `yadk.fetch(function (data) { ... })`


## 当前版本及改进

[v1.0.5] - 2016-05-13

- 支持 https 请求，请求地址为 [https://shared-https.ydstatic.com/js/yadk/1.0.5.js](https://shared-https.ydstatic.com/js/yadk/1.0.5.js)
- 增加 [Q&A](./Q&A.md)

[Change log](./CHANGELOG.md)

## API 参考

目前提供五个 API：

- yadk.config： 配置全局信息，如广告位 ID，设备号，网络连接类型等等
- yadk.fetch： 获取广告数据
- yadk.showed： 成功展示后，调用该方法通知各服务器
- yadk.downloadStarted: 如果媒体是app且展示的是下载类广告，调用该方法通知服务器下载广告开始下载
- yadk.downloadEnded: 如果媒体是app且展示的是下载类广告，调用该方法通知服务器下载广告下载完成

### yadk.config

#### 全局配置

设置全局配置项，参数为 Object 对象。

- 在使用 `yadk.fetch` 获取广告数据前，需要先调用该接口配置广告请求的必要信息，说明见下表：
- `yadk.config` 中配置的参数，在调用 `yadk.fetch` 时，会一起发送给广告服务器

| key | 描述 |
| --- | ---- |
| id | 在开发者系统中获取， **可以是系统定向广告位，也可以是无系统定向的广告位**， ( **必填** )  |
| andAdID | android定向广告位ID ( **选择性填写** ) |
| iosAdID | ios定向广告位ID ( **选择性填写** ) |
| nt | 当前网络连接类型 ( 取值为 WIFI、3G、4G 或 UNKNOWN ， **必填** ) |
| udid | 设备唯一标识 ( 设备ID，app上填写 android ID或 ios系统的 IDFA，web上可以填写用户 cookie 或者其它与当前用户具有一对一关系且不随时间变化的字符串， **与imei填写一个即可** ) |
| imei | 设备号 ( app上需要填写， **imei与udid填写一个即可** ，如果是 android 环境且填写了imei，那么就可以不用填写 udid值 ) |
| brandFirst | 品牌广告优先展示 ( 如果需要优先展示品牌广告，可以将该参数设定为 `true`或 `1`， **选择性填写** ) |


代码示例:

```js
//配置1：ios app上获取广告前的配置
yadk.config({
    id: 'a808997d908bd299713c74d7b1278747',
    nt: '3G',
    udid: 'a023dc7b98d27d13c7b'    //IDFA
})

//配置2：app上有操作系统定向的获取广告前的配置
yadk.config({
    andAdID: 'a808997d908bd299713c74d7b1278747',
    iosAdID: 'e890027d9a92f1322c7434d97b888923',
    nt: '3G',
    imei: '352681005520144',        //android的imei号
    udid: 'a023dc7b98d27d13c7b'     //ios的IDFA号
})

//配置3：wap站点上有操作系统定向的获取广告前的配置（udid可以不传，由`yadk`生成）
yadk.config({
    andAdID: 'a808997d908bd299713c74d7b1278747',
    iosAdID: 'e890027d9a92f1322c7434d97b888923',
    nt: '3G'
})

//配置4：优先展示品牌广告的配置（如果是wap站点，udid可以不传，由`yadk`生成）
yadk.config({
    id: 'a808997d908bd299713c74d7b1278747',
    nt: '3G',
    udid: 'a023dc7b98d27d13c7b',   //IDFA
    brandFirst: 1
})
```

**说明：**

*&nbsp;&nbsp;&nbsp;&nbsp;有道智选广告系统在响应广告请求的时候，会根据系统环境和广告位属性做投放上的优化，体现在如果广告位是android定向，而当前请求广告的是非android系统环境，那么投放系统是不会投放广告的；反之亦然。*

*&nbsp;&nbsp;&nbsp;&nbsp;所以，如果媒体在开发者系统分别设置了android定向和ios定向的广告位，那么在调用接口`yadk.config`进行配置的时候，使用配置2的方式较为简单；在请求广告的时候，yadk会自动匹配对应的广告位ID*

*&nbsp;&nbsp;&nbsp;&nbsp; __品牌广告优先展示__，媒体需要先联系运营创建品牌广告位，然后找有道广告后台设置与效果广告位的关联关系，最后再传参数发起请求才能查看到效果*


#### 多样式广告

从1.0.2版本开始，yadk支持获取指定样式的广告，即获取广告位支持的多种样式中的某种广告。获取指定样式广告有两种方式：根据样式名称获取广告和根据广告展示位置获取广告，具体说明如下：

- 根据样式名称获取广告：在调用`yadk.config`接口的时候设置参数rstyle，该参数指定了要获取的广告的样式名称。

- 根据广告展示位置获取广告：媒体需要在页面信息流的一些特定位置投放广告，且这些位置的广告的样式是之前定义好的固定样式，这类需求可以通过 MAGIC_NO 来实现。目前该方法主要服务于有特定需求的媒体，故此处不作详述，想了解更多，可查看 [MAGIC_NO 使用说明](./MAGIC_NO.md)。

代码示例：

```js
//根据样式名称获取广告
yadk.config({
    id: 'a808997d908bd299713c74d7b1278747',
    nt: '3G',
    rstyle: 'testStyle'
})
```

*注意：获取多样式广告，如果指定样式的广告没有广告商投放，那么系统会返回其他样式的广告，最终返回的广告的样式可以根据 styleName 进行判断。*


#### 自定义参数

如果需要调用yadk时传递一些额外的参数，也可以使用`yadk.config`进行配置。比如：

```js
//自定义参数例子
yadk.config({
    customParams: 'value'
});
```

[自定义参数例子：行为定向](./行为定向.md)

### yadk.fetch

获取广告数据。接口定义如下，参数说明
- ran ：一次请求的广告数目（default = 1），取值范围 [1, 20]，推荐范围[1,3]
- callback ：获取广告成功后的回调函数，回调函数的参数为广告数据，如果是1条广告，则为 object 类型，多条则为 object 数组。

```js
yadk.fetch = function (ran, callback) {...}
```

主要有两种使用方式，如下：

```js
// 方式一：默认取一条广告
yadk.fetch(function(data){
    // data 为 object
})

// 方式二：取指定数量的广告
yadk.fetch(3, function(data){
    // data 为长度为 3 的数组
    // 如果对应的广告 ID 没有 3 条广告，则，有几条返回几条
})
```

#### `yadk.fetch` 的回调函数（callback）参数（data）说明

`yadk.fetch(function (data) { ... })` 中 data 的数据格式说明如下：

- 如果请求的是单个广告，那么data是 ___object类型___；如果请求的是批量广告，那么data是 ___object数组___。
- 其中 `styleName`、 `clktracker`、 `imptracker`、 `ydAdType`、 `isBrand` 和 `ydBid` 字段肯定存在，其它字段不一定会出现，需要查看广告开发者系统中广告位的具体配置；
- 下面仅列出最常用的一些字段，可能还有其它字段（key 不定）

```json
//单个广告
{
    styleName  : '', // [required] - 广告样式名称
    title      : '', // [optional] - 标题
    text       : '', // [optional] - 正文 or 摘要
    mainimage  : '', // [optional] - 主图
    clk        : '', // [optional] - 超链接 url，用于 android/ios SDK
    clktracker : '', // [required] - 带计数的超链接 url，务必使用这个 url，不然没钱拿哦
    imptracker : [], // [required] - 广告成功展示后，需通知数组中所列的服务 url
    iconimage  : '', // [optional] - 小图,
    isBrand    : '', // [required] - 广告是否是品牌广告，true-是，false-不是（效果广告）
    ydAdType   : 0,  // [required] - 广告下载类型，0-非下载，1-一键下载，2-详情页下载
    ydBid      : ''  // [required] - 调用`yadk.downloadStarted`和`yadk.downloadEnded`的时候需要传递的参数
}

//多个广告
[
    {...},
    {...},
    ......
]
```

### yadk.showed

当某个广告在界面上成功展示后，此时需要通知各服务已展示成功。各服务的地址由广告数据的 `imptracker` 字段指定。接口 `yadk.showed` 的作用就是通知各服务。使用方式如下：

```js
yadk.showed(imptracker);
//or
yadk.showed(imptracker, function() {
    //上报完成后do something
});
```

_`yadk.showed`支持品牌广告和效果广告的展示上报，调用方法相同_

### yadk.downloadStarted

该接口主要提供给app媒体使用，当某个广告位展示的是下载类广告，如果用户点击下载app，此时需要在下载开始的时候发送下载统计信息给下载统计服务。

`yadk.downloadStarted`就是完成通知下载服务器的工作。此时需要传递一些下载app的相关信息，参数为Object，用法如下：

```js
var params = {
    variantId:     '', // [required] - 请求到的广告变体id ( 可以在返回的广告中获取 )
    bid:           '', // [required] - 请求到的广告变体ydBid（ 返回的广告中获取 ）
    pkgName:       '', // [required] - 下载的app的包名
    appVersion:    '', // [required] - 下载的app的版本
    appName:       ''  // [required] - 下载的app的名字
};

yadk.downloadStarted(params);
```

***注意：如果集成yadk的媒体是app，那么需要发送下载统计信息，否则可能会影响广告收益。
考虑到移动设备浏览器和pc浏览器功能上的限制，如果集成yadk的媒体的页面是在移动浏览器和pc浏览器上展示的话，则不要求必须发送下载统计信息。***

### yadk.downloadEnded

`yadk.downloadEnded`是在下载结束的时候调用以通知下载统计服务器。其用法与`yadk.downloadStarted`一致，所需参数也一样，此处不再详述。


## 附1 - 测试说明

web 版广告 SDK 需要考虑兼容所有浏览器平台，所以需要在如下浏览器中测试通过：

- IE 6 +
- Chrome
- Firefox
- Safari
- Opera
- iOS 和 Android 系统默认浏览器

## 附2 - 操作系统内部编码对应关系

| os type | os value |
| ----- | ----- |
| iphone | 0 |
| ipad | 1 |
| mac | 2 |
| android | 3 |
| android_tablet | 4 |
| win_tablet | 5 |
| windows | 6 |
| win_phone | 7 |
| linux | 8 |
| other | 9 |
