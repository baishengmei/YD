
//var webpack = require('webpack');

module.exports = {

    entry: {
        'yadk': './src/js/yadka.js',
        //'Download': './src/js/yadkDownload.js',
        //'Fetch': './src/js/yadkFetch.js',
        //'Showed' : './src/js/yadkShowed.js'
    },

    output: {
        path: './dist/js',
        filename: "[name].js",
        pathinfo: true
    },

    plugins: [
        /*new webpack.optimize.UglifyJsPlugin({
         compress: {
         warnings: true
         },
         })*/
    ]

};