
module.exports = auxiliaryFunc;

function auxiliaryFunc(){
    var
        emptyArr = [],
        emptyObj = {},
        toString = emptyObj.toString,
        hasOwnProperty = emptyObj.hasOwnProperty;

    var hasOwn = function(obj, prop){
        return hasOwnProperty.call(obj, prop);
    };

    var auxiliaryFunc = {
        isFunction : function (obj) {
            return toString.call(obj) === "[object Function]";
        },

        isString : function (obj) {
            return toString.call(obj) === "[object String]";
        },

        isObject : function (obj) {
            return toString.call(obj) === "[object Object]";
        },

        isNumber : function (obj) {
            return toString.call(obj) === "[object Number]";
        },

        isDate : function(obj) {
            return toString.call(obj) === "[object Date]";
        },

        forEach : emptyArr.forEach ?
            function(arr, fn) {
                arr || (arr = []);
                arr.forEach(fn);
            } :
            function(arr, fn) {
                arr || (arr = []);
                for (var i = 0, len = arr.length; i < len; i++) {
                    fn(arr[i], i, arr);
                }
            },

        keys : Object.keys || function (obj) {
            var ret = [];
            for (var p in obj) {
                if (hasOwn(obj, p)) {
                    ret.push(p);
                }
            }
            return ret;
        }
    };

    return auxiliaryFunc;
}
