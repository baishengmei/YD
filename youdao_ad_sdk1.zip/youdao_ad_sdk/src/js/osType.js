module.export =  (function () {
    var ua = navigator.userAgent.toLowerCase() || '',
        osTypeMap = {
            'iphone': 0,
            'ipad': 1,
            'mac': 2,
            'android': 3,
            'android_tablet': 4,
            'win_tablet': 5,
            'windows': 6,
            'win_phone': 7,
            'linux': 8,
            'other': 9
        },
        is = {};

    is.iphone = /iphone/.test(ua);
    is.ipad = /ipad/.test(ua);
    is.mac = /mac/.test(ua);
    is.mobile = /mobile/.test(ua);
    is.android = /android/.test(ua);
    is.android_tablet = is.android && !is.mobile;
    is.windows = /windows/.test(ua);
    is.win_phone = is.windows && /phone/.test(ua);
    is.win_tablet = is.windows && !is.win_phone && /touch/.test(ua);
    is.linux = /linux/.test(ua);

    var osType = '';

    switch(true) {
        case is.iphone:
            osType = 'iphone';
            break;
        case is.ipad:
            osType = 'ipad';
            break;
        case is.mac:
            osType = 'mac';
            break;
        case is.android_tablet:
            osType = 'android_tablet';
            break;
        case is.android:
            osType = 'android';
            break;
        case is.win_phone:
            osType = 'win_phone';
            break;
        case is.win_tablet:
            osType = 'win_tablet';
            break;
        case is.windows:
            osType = 'windows';
            break;
        case is.linux:
            osType = 'linux';
            break;
        default:
            osType = 'other';
    }

    return {
        name: osType,
        value: osTypeMap[osType],
        isIOS: is.iphone || is.ipad,
        isAndroid: is.android || is.android_tablet
    };
})();
