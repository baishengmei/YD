;(function (global, undefined) {
// -----------------------------------------------------------------------------
    var auxiliaryFunc = require("./auxiliaryFunc");
    var format = require("./format");
    var cookie = require("./cookieManager");

    if (global.yadk) {
        return;
    }

    var yadk = global.yadk = {
        version: "@VERSION@"
    };

    var userIdCookieKey = '__yadk_uid';

    var win = window,
        doc = document;

    var formatString = yadk.formatString = format.formatString;
    var formatDate = yadk.formatDate = format.formatDate;

    var cookieManager = cookie();

//生成指定长度的key
    function getUniqueKey(length) {
        var str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        var key = '';
        for(var i = 0, index; i < length; i++) {
            index = Math.floor( Math.random() * str.length );
            key += str[index];
        }
        return key;
    }

//确保生成了user cookie id
    function assertUserId() {
        if ( !userId ) {
            userId = getUniqueKey(32);
            cookieManager.setCookie(userIdCookieKey, userId, 365, '/');
        }
    }

    var obj2UrlString = function (obj) {
        if (!isObject(obj)) return '';
        var r = [];
        forEach(keys(obj), function (k, idx) {
            r.push(k + '=' + encodeURIComponent(obj[k]));
        });
        return r.join('&');
    };

//获取os的类型
    var osType = (function () {
        var ua = navigator.userAgent.toLowerCase() || '',
            osTypeMap = {
                'iphone': 0,
                'ipad': 1,
                'mac': 2,
                'android': 3,
                'android_tablet': 4,
                'win_tablet': 5,
                'windows': 6,
                'win_phone': 7,
                'linux': 8,
                'other': 9
            },
            is = {};

        is.iphone = /iphone/.test(ua);
        is.ipad = /ipad/.test(ua);
        is.mac = /mac/.test(ua);
        is.mobile = /mobile/.test(ua);
        is.android = /android/.test(ua);
        is.android_tablet = is.android && !is.mobile;
        is.windows = /windows/.test(ua);
        is.win_phone = is.windows && /phone/.test(ua);
        is.win_tablet = is.windows && !is.win_phone && /touch/.test(ua);
        is.linux = /linux/.test(ua);

        var osType = '';

        switch(true) {
            case is.iphone:
                osType = 'iphone';
                break;
            case is.ipad:
                osType = 'ipad';
                break;
            case is.mac:
                osType = 'mac';
                break;
            case is.android_tablet:
                osType = 'android_tablet';
                break;
            case is.android:
                osType = 'android';
                break;
            case is.win_phone:
                osType = 'win_phone';
                break;
            case is.win_tablet:
                osType = 'win_tablet';
                break;
            case is.windows:
                osType = 'windows';
                break;
            case is.linux:
                osType = 'linux';
                break;
            default:
                osType = 'other';
        }

        return {
            name: osType,
            value: osTypeMap[osType],
            isIOS: is.iphone || is.ipad,
            isAndroid: is.android || is.android_tablet
        };
    })();

// An internal function for creating assigner functions.
    var createAssigner = function(undefinedOnly) {
        return function(obj) {
            var length = arguments.length;
            if (length < 2 || obj == null) return obj;
            for (var index = 1; index < length; index++) {
                var source = arguments[index],
                    ks = keys(source),
                    l = ks.length;
                for (var i = 0; i < l; i++) {
                    var k = ks[i];
                    if (!undefinedOnly || obj[k] === void 0) obj[k] = source[k];
                }
            }
            return obj;
        };
    };

    var extend = createAssigner();

// -----------------------------------------------------------------------------
// 参考 jQuery jsonp 见 https://github.com/jaubourg/jquery-jsonp
// 一篇相关的中文介绍 http://blog.csdn.net/cainiaokan/article/details/10960607
//
// 做为广告平台的 web sdk，需要考虑兼容全平台浏览器，jquery 是个值得参考的好对象，毕竟人
// 家经历了全球开发者的测试和时间的考验

    var jsonp = yadk.jsonp = (function() {
        // Noop
        function noop() {}

        // Generic callback
        function genericCallback( data ) {
            lastValue = [ data ];
        }

        // Call if defined
        function callIfDefined( method , object , params ) {
            return method && method.apply
                && method.apply( object.context || object , params );
        }

        // Give joining character given url
        function qMarkOrAmp( url ) {
            return /\?/ .test( url ) ? "&" : "?";
        }

        function newTag( tagName ) {
            return doc.createElement(tagName || 'div');
        }

        function getByTagName( tagName, ctx ) {
            ctx || (ctx = doc);
            return ctx.getElementsByTagName(tagName);
        }

        var // String constants (for better minification)
            STR_ASYNC                 = "async",
            STR_CHARSET               = "charset",
            STR_EMPTY                 = "",
            STR_ERROR                 = "error",
            STR_INSERT_BEFORE         = "insertBefore",
            STR_YAD_JSONP             = "_yad_jsonp",
            STR_ON                    = "on",
            STR_ON_CLICK              = STR_ON + "click",
            STR_ON_ERROR              = STR_ON + STR_ERROR,
            STR_ON_LOAD               = STR_ON + "load",
            STR_ON_READY_STATE_CHANGE = STR_ON + "readystatechange",
            STR_READY_STATE           = "readyState",
            STR_REMOVE_CHILD          = "removeChild",
            STR_SCRIPT_TAG            = "script",
            STR_SUCCESS               = "success",
            STR_TIMEOUT               = "timeout",

        // Head element
            head = doc.head || getByTagName("head")[0],
        // Page cache
            pageCache = {},
        // Counter
            count = 0,
        // Last returned value
            lastValue,

        // DEFAULT OPTIONS
            xOptionsDefaults = {
                url           : location.href,
                cache         : false,
                pageCache     : false,
                charset       : 'UTF-8',
                jsonp         : 'callback',
                jsonpCallback : STR_YAD_JSONP,
                // success    : undefined,
                // error      : undefined,
                // complete   : undefined,
                // context    : undefined,
                // data       : "",
                // dataFilter : undefined
                timeout       : 0
            },

        // opera demands sniffing :/
            opera = win.opera,

        // IE < 10
            oldIE = (function() {
                var div = newTag();
                div.innerHTML = "<!--[if IE]><i></i><![endif]-->";
                return !!getByTagName('i', div).length;
            })();

        // -------------------------------------------------------------------------
        // MAIN FUNCTION
        function jsonp( xOptions ) {

            // Build data with default
            xOptions = extend({}, xOptionsDefaults, xOptions);

            // References to xOptions members (for better minification)
            var successCallback     = xOptions.success,
                errorCallback       = xOptions.error,
                completeCallback    = xOptions.complete,
                dataFilter          = xOptions.dataFilter,
                jsonpName           = xOptions.jsonp,
                jsonpCallback       = xOptions.jsonpCallback + '_' + (count++),
                cacheFlag           = xOptions.cache,
                pageCacheFlag       = xOptions.pageCache,
                charset             = xOptions.charset,
                url                 = xOptions.url,
                data                = xOptions.data,
                timeout             = xOptions.timeout,

                pageCached,

            // Abort/done flag
                done    = 0,

            // Life-cycle functions
                cleanUp = noop,

            // Request execution vars
                firstChild,
                script,
                scriptAfter,
                timeoutTimer;

            // Create the abort method
            xOptions.abort = function() {
                !( done++ ) && cleanUp();
            };

            // Control entries
            url = url || STR_EMPTY;
            data = data ? (isString(data) ? data : obj2UrlString(data)) : STR_EMPTY;

            // Build final url
            url += data ? ( qMarkOrAmp( url ) + data ) : STR_EMPTY;

            // Add jsonp callback parameter
            url += qMarkOrAmp( url ) + jsonpName + '=' + jsonpCallback;

            // Add anticache parameter if needed
            if (!cacheFlag && !pageCacheFlag) {
                url += qMarkOrAmp( url ) + "_" + ( new Date() ).getTime();
            }

            // Success notifier
            function notifySuccess( json ) {
                if ( done++ ) return;

                cleanUp();
                // Pagecache if needed
                pageCacheFlag && ( pageCache [ url ] = { s: [ json ] } );
                // Apply the data filter if provided
                dataFilter && ( json = dataFilter.apply( xOptions , [ json ] ) );
                // Call success then complete
                callIfDefined( successCallback , xOptions ,
                    [ json , STR_SUCCESS, xOptions ] );
                callIfDefined( completeCallback , xOptions ,
                    [ xOptions , STR_SUCCESS , json] );
            }

            // Error notifier
            function notifyError( type ) {
                if ( done++ ) return;

                // Clean up
                cleanUp();
                // If pure error (not timeout), cache if needed
                pageCacheFlag && type != STR_TIMEOUT && ( pageCache[ url ] = type );
                // Call error then complete
                callIfDefined( errorCallback , xOptions , [ xOptions , type ] );
                callIfDefined( completeCallback , xOptions , [ xOptions , type ] );
            }

            // Check page cache
            if ( pageCacheFlag && ( pageCached = pageCache[ url ] ) ) {
                pageCached.s ? notifySuccess( pageCached.s[ 0 ] )
                    : notifyError( pageCached );
            } else {
                // Install the generic callback
                // (BEWARE: global namespace pollution ahoy)
                win[ jsonpCallback ] = genericCallback;

                // Create the script tag
                script = newTag( STR_SCRIPT_TAG );
                script.id = jsonpCallback;

                // Set charset if provided
                if ( charset ) {
                    script[ STR_CHARSET ] = charset;
                }

                opera && opera.version() < 11.60 ?
                    // onerror is not supported: do not set as async and assume
                    // in-order execution. Add a trailing script to emulate the event
                    ( ( scriptAfter = newTag( STR_SCRIPT_TAG ) ).text = ''
                        + "document.getElementById('" + script.id + "')."
                        + STR_ON_ERROR + "()" )
                    :
                    // onerror is supported: set the script as async to avoid
                    // requests blocking each others
                    ( script[ STR_ASYNC ] = STR_ASYNC )

                ;

                // Internet Explorer: event/htmlFor trick
                if ( oldIE ) {
                    script.htmlFor = script.id;
                    script.event = STR_ON_CLICK;
                }

                // Attached event handlers
                script[ STR_ON_LOAD               ] =
                    script[ STR_ON_ERROR              ] =
                        script[ STR_ON_READY_STATE_CHANGE ] = function ( result ) {
                            // Test readyState if it exists
                            if ( !script[ STR_READY_STATE ] ||
                                !/i/.test( script[ STR_READY_STATE ] ) ) {
                                try {
                                    script[ STR_ON_CLICK ] && script[ STR_ON_CLICK ]();
                                } catch( _ ) {}

                                result = lastValue;
                                lastValue = 0;
                                result ?
                                    notifySuccess( result[ 0 ] ) :
                                    notifyError( STR_ERROR );
                            }
                        };

                // Set source
                script.src = url;

                // Re-declare cleanUp function
                cleanUp = function( i ) {
                    timeoutTimer && clearTimeout( timeoutTimer );
                    script[ STR_ON_READY_STATE_CHANGE ] =
                        script[ STR_ON_LOAD               ] =
                            script[ STR_ON_ERROR              ] = null;
                    head[ STR_REMOVE_CHILD ]( script );
                    scriptAfter && head[ STR_REMOVE_CHILD ]( scriptAfter );
                    win[ jsonpCallback ] = null;
                };

                // Append main script
                head[ STR_INSERT_BEFORE ](
                    script , ( firstChild = head.firstChild ) );

                // Append trailing script if needed
                scriptAfter && head[ STR_INSERT_BEFORE ](
                    scriptAfter , firstChild );

                // If a timeout is needed, install it
                timeoutTimer = timeout > 0 && setTimeout( function() {
                        notifyError( STR_TIMEOUT );
                    } , timeout );

            }

            return xOptions;
        }

        return jsonp;
    })();

// -----------------------------------------------------------------------------

//生成cookie
    var userId = cookieManager.getCookie(userIdCookieKey);
    assertUserId();

    var protocol = location.protocol === 'https:' ? 'https:' : 'http:';


// 相关的全局变量和辅助函数
// var requestUrl = 'http://dingzq.iyoudao.net/apis/yad-ajax.php';
//var requestUrl = 'http://nb260x.corp.youdao.com:18088/gorgon/request.s';
//var requestUrl = 'http://test1.gorgon.youdao.com/gorgon/request.s';
    var requestUrl = protocol + '//gorgon.youdao.com/gorgon/request.s';
//品牌广告展示统计URL
    var brandShowedUrl = protocol + '//gorgon.youdao.com/gorgon/mimpr.s';
// Sdk转化跟踪最终请求URL，即统计下载信息的URL
    var downloadStatUrl = protocol + '//conv.youdao.com/api/push/youdao';

    var default_config = {
        //当前SDK的身份
        reqfrom: 'web',
        webos: osType.value,
        // 当前 SDK 的版本号
        nsv: yadk.version
    };

//发送广告展示和点击统计信息的参数config
    var global_config = {};

    function checkRan(n) {
        return n > 20 ? 20 : (n <= 0 ? 1 : n);
    }

// -----------------------------------------------------------------------------
// API

// 设置全局配置项，一般来说，这些配置项可再网易有道广告系统中获得
// 目前针对 web 版的 SDK 必须字段包括广告位ID、网络连接类型ct、子网络连接类型dct、
// 设备唯一标识udid（设备ID，如android ID或IDFA）和设备号imei,
// 这里为了简化用户输入，将参数名称和传参方式做了一些改动
// params: {
//      id : 'string'，
//      'nt': '3G',
//      'udid': 'string',
//      'imei': 'string'
// }

    var networkType = {
            UNKNOWN: 'UNKNOWN',
            //ETHERNET: 'ETHERNET',//移动广告不存在ethernet
            WIFI: 'WIFI',
            '3G': '3G',
            '4G': '4G'
        },
        networkTransType = {
            UNKNOWN: 0,
            //ETHERNET: 1,
            WIFI: 2,
            '3G': 3,//3G and 4G　are two types of mobile
            '4G': 3
        };

    yadk.config = function (params) {
        var type = params.nt && params.nt.replace(/^\s+|\s+$/g, '');

        if( type ) {

            delete params.dct;
            delete params.ct;
            delete params.nt;

            switch( type = type.toUpperCase() ) {
                case networkType['3G']:
                case networkType['4G']:
                    params.ct = networkTransType[type];
                    params.dct = type === '3G' ? 12 : 13;
                    break;
                //case networkType['ETHERNET']:
                case networkType['WIFI']:
                case networkType['UNKNOWN']:
                    params.ct = networkTransType[type];
                    delete params.dct;
                    delete global_config.dct;
                    break;
                default:
                    params.ct = networkTransType[networkType['UNKNOWN']];
                    delete params.dct;
                    delete global_config.dct;
            }
        }

        if ( 'brandFirst' in params ) {
            if ( params.brandFirst ) {
                params.MAGIC_NO = 0;//brand first position
            }
            delete params.brandFirst;
        }

        //support debug mode
        if ( 'debug' in params && params.debug === true ) {
            delete params.debug;
            if ( 'reqUrl' in params ) {
                requestUrl = params.reqUrl;
                delete params.reqUrl;
            }
            if ( 'brandShowedUrl' in params ) {
                brandShowedUrl = params.brandShowedUrl;
                delete params.brandShowedUrl;
            }
        }

        extend(global_config, {udid: userId}, params, default_config);

        if (osType.isIOS) {
            global_config.id = global_config.iosAdID || global_config.id;
            delete global_config.imei;
        } else if (osType.isAndroid) {
            global_config.id = global_config.andAdID || global_config.id;
        } else {
            delete global_config.imei;
        }

        return global_config;
    };

// 取广告数据
// ran      : 一次请求的广告数目，最大不能超过20个
// callback : 获取成功后的回调
    yadk.fetch = function (ran, callback) {

        if (!global_config.id) {
            return;
        }

        if (isFunction(ran)) {
            callback = ran;
            ran = 1;
        }
        !isNumber(ran) && (ran = 1);
        ran = checkRan(ran);

        var data = extend({}, global_config, {ran: ran});

        if (data.iosAdID) {
            delete data.iosAdID;
        }
        if (data.andAdID) {
            delete data.andAdID;
        }
        if ( global_config.imei ) {
            delete global_config.udid;
        }


        //JSONP是一种依靠开发人员的聪明才智创造出的一种非官方跨域数据交互协议
        jsonp({
            url: requestUrl,
            data: data,
            // success : [ xOptions , STR_SUCCESS , json]
            // error   : [ xOptions , type ]
            complete: function (ox, status, data) {
                !data && (data = []);

                if ( (data['X-Cost-Type'] || '').toLowerCase() === "brand"){
                    data.isBrand= true;
                    delete data['X-Cost-Type'];
                } else {
                    data.isBrand = false;
                }

                data.mainimage = data.mainimage || data.iconimage;

                'length' in data || ( data = [ data ] );

                isFunction(callback) && callback.call(yadk, data);
            }
        });

    };

//img get 发送数据
    function notifyUrl(url, callback) {
        //防止浏览器缓存导致二次发送失败（直接读取缓存结果）
        url = url + ( /\?/.test(url) ? '&' : '?' ) + 't=' + (+new Date);

        var img = new Image();
        img.onload = img.onerror = function () {
            this.onload = this.onerror = null;
            img = null;
            callback && callback('success');
        };

        img.src = url;
    }

// 当某个广告展示成功后，需要通知各服务我已经展示了，哦也！
// 每个广告对象，都会有一个 imptracker 字段，该字段是一个数组，可能包含一个或多个 url
// showed 方法需要触发每个 url 请求
//
// 2016-03-16 支持品牌广告展示上报
//品牌广告展示成功后通知服务器已经展示了，用法同yadk.showed
//参数格式说明: https://dev.corp.youdao.com/outfoxwiki/Advertisement/admob/androidsdk/multinative-request#preview
    yadk.showed = function(imptracker, callback) {
        imptracker || ( imptracker = [] );
        var cnt = 0;
        forEach(imptracker, function(tracker){
            if ( '?' === tracker[0] ) {
                //toISOString支持IE9+
                var param = {
                    type: 'brandImpr',
                    imptracker: [ tracker.substr(1) + '#@$' + formatDate(new Date(), 'yyyyMMddhhmmss') ]
                };
                var url = formatString('{0}?s={1}', brandShowedUrl, encodeURIComponent(JSON.stringify(param)) );
                notifyUrl(url, ifDone);
            } else {
                notifyUrl(tracker, ifDone);
            }
        });

        function ifDone() {
            if ( ++cnt === imptracker.length ) {
                isFunction(callback) && callback();
            }
        }
    };


//发送下载统计的参数config
//必填信息包括
//imei:请求广告设备的设备号( imei与下面的udid填写一个即可 )
//udid:设备唯一标识udid ( 设备ID，如android ID或IDFA，也可以是能标定当前用户、有一对一关系且不变的字符串 )
//除了下面这些必填项，还包括
//一些信息。 e.g.
//pkgName #下载的app的包名
//appVersion #下载的app的版本
//appName #下载的app的名字


//获取下载统计url
    function getDLStatUrl(config) {
        var url = downloadStatUrl,
            data = config ? (isString(config) ? config : obj2UrlString(config)) : "";

        data && (url += (/\?/.test(url) ? '&' : '?' ) + data);

        return url;
    }

    yadk.downloadStarted = function(params, callback) {
        if (!global_config.id) {
            return;
        }
        var config = {
            slotId: global_config.id,
            os: osType.name,
            varaiantId: 0
        };

        if (global_config.imei) {
            config.imei = global_config.imei;
        } else if (global_config.udid) {
            config.udid = global_config.udid;
        }

        extend(config, params, {IDS: 0});
        notifyUrl(getDLStatUrl(config), callback);
    };

    yadk.downloadEnded = function(params, callback) {
        if (!global_config.id) {
            return;
        }
        var config = {
            slotId: global_config.id,
            os: osType.name,
            varaiantId: 0
        };

        if (global_config.imei) {
            config.imei = global_config.imei;
        } else if (global_config.udid) {
            config.udid = global_config.udid;
        }

        extend(config, params, {IDS: 1});
        notifyUrl(getDLStatUrl(config), callback);
    };

// -----------------------------------------------------------------------------
})(this);
