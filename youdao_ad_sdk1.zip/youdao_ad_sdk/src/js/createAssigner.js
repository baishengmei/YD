module.export = createAssigner;

var hasOwn  = function (obj, prop) {
    return hasOwnProperty.call(obj, prop);
};

var keys = Object.keys || function (obj) {
        var ret = [];
        for (var p in obj) {
            if (hasOwn(obj, p)) {
                ret.push(p);
            }
        }
        return ret;
    };

// An internal function for creating assigner functions.
function createAssigner(undefinedOnly) {
    return function(obj) {
        var length = arguments.length;
        if (length < 2 || obj === null) return obj;
        for (var index = 1; index < length; index++) {
            var source = arguments[index],
                ks = keys(source),
                l = ks.length;
            for (var i = 0; i < l; i++) {
                var k = ks[i];
                if (!undefinedOnly || obj[k] === void 0) obj[k] = source[k];
            }
        }
        return obj;
    };
}

