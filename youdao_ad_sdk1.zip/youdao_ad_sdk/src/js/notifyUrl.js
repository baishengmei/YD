
module.export = notifyUrl;

//img get 发送数据
function notifyUrl(url, callback) {
    //防止浏览器缓存导致二次发送失败（直接读取缓存结果）
    url = url + ( /\?/.test(url) ? '&' : '?' ) + 't=' + (new Date);

    var img = new Image();
    img.onload = img.onerror = function () {
        this.onload = this.onerror = null;
        img = null;
        callback && callback('success');
    };

    img.src = url;
}
