var format = require("./format");

var formatString = format.formatString;

module.exports = cookieManger;
function cookieManger(){

    var cookie = {
        getCookie: function(name) {
            var re = new RegExp("(?:(?:^|.*;\\s*)" + name + "\\s*=\\s*([^;]*).*$)|^.*$");
            var m = re.exec(document.cookie);
            return m[1] && unescape(m[1]);
        },
        setCookie: function(name, value, expireDay, path) {
            path || (path = '/');
            var expires;
            if ( expireDay ) {
                var d = new Date();
                d.setTime( d.getTime() + expireDay * 24 * 60 * 60 * 1000 );
                expires = d.toGMTString();
            }

            var s = formatString('{0}={1};expires={2};path={3}', name, escape(value), expires, path);
            document.cookie = s;
        },
        delCookie: function(name) {
            var val = cookieManager.getCookie(name);
            if ( val ) {
                var d = new Date();
                d.setTime(d.getTime() - 1);
                document.cookie = formatString('{0}={1};expires={2}', name, escape(val), d.toGMTString());
            }

        }
    };

    return cookie;
}