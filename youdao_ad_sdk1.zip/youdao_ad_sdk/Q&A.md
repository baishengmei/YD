## YADK Questions And Answers

这里总结了用 YADK 集成广告时遇到的一些常见问题，建议出现问题的时候先阅读本文。


1.  Q: 新建了广告位，为什么自测的时候没有返回广告？<br>
    A: 如下图所示，请点击下一步进入自测环节，此时上方的导航条中自测变为蓝色代表可以自测，此时系统才会自动创建测试物料；否则是没有广告返回的。
        
    ![自测流程][testflow]

1.  Q: 页面不是集成在App中，网络类型 `nt` 应该填写什么值？<br>
    A: 如果获取网络类型不方便的话，根据页面的展示环境填写一个贴近实际情况的值，比如词典桌面广告页面，推荐WIFI；只在移动端显示的页面，推荐 `3G` 和 `4G`。

1.  Q: 使用js sdk接入 PC 广告，为什么自测的时候没有返回广告？<br>
    A: 现在的广告系统的自测物料中投放的是移动自测物料，所以没有返回。可以使用下面的 trick 方式获取自测物料。

        var config = yadk.config({
            id: 'xxxxxxxxxxxxxxxxxxx',
            nt: 'WIFI'
        });

        config.webos = 3;

    但是，审核的时候需要将`config.webos = 3;`去掉，否则会影响广告收益，且审核不通过。

1.  Q: 已经排除上面提到的没有自测广告的原因，但为什么自测时依然没有广告返回？<br>
    A: 针对这种情况，有可能是顾问/运营在投放的时候对加了某种[限制/过滤规则][filter]，导致自测广告被过滤掉了。所以可以问一下顾问/运营。如果不存在这种情况，那么可以找广告同学帮助排查。

1.  Q: 利用下面的代码请求多条广告的时候，为什么只返回了一条？<br>
    A: 有两种情况会导致这个问题
        
        1： 广告位未通过审核，系统返回的广告数据是自测物料，只有1条； 
        2：已通过审核的广告位，说明定向到当前环境（android、ios、web...）下的物料只有一套，请在智选系统中检查创意投放是否正确。

___To Be Continued ...___


[testflow]: https://gitlab.corp.youdao.com/webfront-ad/youdao_ad_sdk/raw/master/images/1.png "自测流程"
[filter]: https://dev.corp.youdao.com/outfoxwiki/Advertisement/DSP/RuleFilter