module.exports = function(grunt) {

  var config = grunt.file.readJSON('package.json');
  var version = config.version;

  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json'),

    connect: {
      server: {
        options: {
          port: 8888,
          keepalive: true,
          hostname: "*"
        }
      },
    },

    uglify: {
      options: {
        compress: {
          drop_console: true
        }
      },
      main: {
        files: {
          './dist/<%=pkg.version%>.js': [
            './dist/<%=pkg.version%>-dev.js'
          ]
        }
      }
    },

    copy: {
      main: {
        src: './src/yadk.js',
        dest: './dist/<%=pkg.version%>-dev.js',
        options: {
          mode: true,
          process: function (content, srcpath) {
            return content.replace(/@VERSION@/g, version);
          },
        },
      }
    },

    clean : ['./dist/']
  });

  grunt.loadNpmTasks('grunt-contrib-connect');
  grunt.loadNpmTasks('grunt-contrib-uglify');
  grunt.loadNpmTasks('grunt-contrib-copy');
  grunt.loadNpmTasks('grunt-contrib-clean');

  grunt.registerTask('default', ['connect:server']);
  grunt.registerTask('build', ['clean', 'copy:main', 'uglify:main']);

};