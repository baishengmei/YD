## YADK CHANGE LOG

### [v1.0.5] - 2016-05-13

- 修复 yadk 在 file:// 协议下无法请求广告的 bug
- 增加 [Q&A](./Q&A.md)

### [v1.0.5] - 2016-04-07

- 支持 https 请求，请求地址为 [https://shared-https.ydstatic.com/js/yadk/1.0.5.js][yadkOnlineHttps1.0.5]

### [v1.0.4] - 2016-03-23

主要增加了对品牌广告的支持，具体的改进包括：

- `yadk.config`支持品牌广告优先，只需要传递参数 **brandFirst**
- `yadk.fetch`获取的广告数据中添加品牌广告和效果广告类型 **isBrand**
- `yadk.fetch`获取的广告数据类型在单个广告和批量广告的时候略有不同
- `yadk.showed`接口支持品牌广告的展示上报


[v1.0.5]: https://gitlab.corp.youdao.com/webfront-ad/youdao_ad_sdk/tree/1.0.5
[v1.0.4]: https://gitlab.corp.youdao.com/webfront-ad/youdao_ad_sdk/tree/1.0.4
[yadkOnlineHttps1.0.5]: https://shared-https.ydstatic.com/js/yadk/1.0.5.js

