function heredoc(fn) {
    return fn.toString()
        .replace(/^[^\/]+\/\*\s*/,'')
        .replace(/\*\/[^\/]+$/,'');
}

var card1 = heredoc(function (){/*
<div class="dl_ad card" style="display: inline-block;">
<i class="card-flag">有道广告</i>
<div class="cardtitle">
  <span class="bigpic"><a href="<%=clktracker%>" target="_blank">
      <i style="height:242px"></i>
      <img src="<%=mainimage%>">
  </a></span>
  <h2>
    <a href="<%=clktracker%>" target="_blank">
      <div class="title-mask"></div>
      <span><%=title%></span>
    </a>
  </h2>
</div>
<div class="abstract">
  <p><%=text%></p>
</div>
</div>
*/});

var card2 = heredoc(function (){/*
<div class="dl_ad card" style="display: inline-block;">
<i class="card-flag">有道广告</i>
<div class="cardtitle">
  <span class="bigpic"><a href="<%=clktracker%>" target="_blank">
      <i style="height:242px"></i>
      <img src="<%=mainimage%>">
  </a></span>
</div>
</div>
*/});

// -----------------------------------------------------------------------------

card1 = _.template(card1)
card2 = _.template(card2)

var wrap = $('#ydAd');

var adid = 'e73959271a634fa2c00b8258a4ee391c';

//详细参数说明请参照说明文档
var config = yadk.config({
  id: adid,
  nt: '3G',
  /* 该样式是在开发者系统中预先定义好的 */
  rstyle: '下载类'
});

//如果android和ios是两个广告位，也可以像下面这么写
//
// yadk.config({
//   andAdID: androidID,
//   iosAdID: iosID,
//   nt: '3G'
// });

var params = [];

yadk.fetch(2, function (data) {
  _.each(data, function (obj, idx) {
    if(obj.styleName !== config.rstyle) {
      return;
    }

    if (obj.title && obj.text) {
      wrap.append(card1(obj))
    }
    else {
      wrap.append(card2(obj))
    }

    yadk.showed(obj.imptracker)

    params.push({
      variantId: obj.creativeid,
      bid: obj.ydBid,
      pkgName: 'test.pkg.name',
      appVersion: '1.0.0'
    });

  });

  var ads = getElementsByClassName(document, 'dl_ad');
  for(var i = 0, ad; ad = ads[i]; i++) {
    if(ad.addEventListener) {
      console.log('addEventListener');
      ad.addEventListener('click', getHandler(params[i]), false);
    } else {
      console.log('onclick');
      ad.attachEvent('onclick', getHandler(params[i]));
    }
  }

});

function getHandler(params) {
  return function (e) {
    if(e.preventDefault){
      e.preventDefault();
    } else {
      e.returnValue = false;
    }
    yadk.downloadStarted(params, function(status) {
      console.log('download start notify', status);
    });
    //downloading apk...
    setTimeout(function(){
      yadk.downloadEnded(params, function(status) {
        console.log('download end notify', status);
      });
    }, 5000);
    return false;
  };
}

function getElementsByClassName(elem, clazz) {
  if(elem.getElementsByClassName) {
    return elem.getElementsByClassName(clazz);
  }

  var elements = elem.getElementsByTagName('*'),
      ret = [];
  for(var i = 0, len = elements.length; i < len; i++) {
    if(elements[i].className.indexOf(clazz) >= 0) {
      ret.push(elements[i]);
    }
  }
  return ret;
}