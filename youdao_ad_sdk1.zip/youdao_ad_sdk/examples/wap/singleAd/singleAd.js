var adid = '2269a437dc751f6854b835ade7b46d13';
adid = '1d627bc7cab65f5651e9e0143776de1b';

var tpl =
  '<div class="ad">' +
    '<label class="label">广告:</label>' +
    '<a href="{0}" target="_blank">' +
      '<div>标题： {1}</div>' +
      '<div>内容： {2}</div>' +
    '</a>' +
  '</div>';

//详细参数说明请参照说明文档
yadk.config({
  id: adid,
  nt: '3G'
});

//如果android和ios是两个广告位，也可以像下面这么写
//
// yadk.config({
//   andAdID: androidID,
//   iosAdID: iosID,
//   nt: '3G'
// });

var wrapper = document.getElementById('ydAd');

yadk.fetch(function (ad) {
  var html = yadk.formatString(tpl, ad.clktracker, ad.title || ad.styleName, ad.text || '未定义描述');
  wrapper.innerHTML = html;

  //广告展示出来（用户能看到才算展示）进行上报，否则没钱赚
  yadk.showed(ad.imptracker);
});