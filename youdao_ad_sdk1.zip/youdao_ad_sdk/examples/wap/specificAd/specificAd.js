function heredoc(fn) {
    return fn.toString()
        .replace(/^[^\/]+\/\*\s*/,'')
        .replace(/\*\/[^\/]+$/,'');
}

var card1 = heredoc(function (){/*
<div class="card" style="display: inline-block;">
  <i class="card-flag">有道广告</i>
  <div class="cardtitle">
    <h2>
      <a href="<%=clktracker%>">
        <span><%=title%></span>
      </a>
    </h2>
  </div>
  <div class="abstract">
    <p><%=text%></p>
  </div>
</div>
*/});

var card2 = heredoc(function (){/*
<div class="card" style="display: inline-block;">
  <i class="card-flag">有道广告</i>
  <div class="cardtitle">
    <span class="bigpic">
      <a href="<%=clktracker%>">
        <i style="height:242px"></i>
        <img src="<%=mainimage%>">
      </a>
    </span>
    <h2>
      <a href="<%=clktracker%>">
        <div class="title-mask"></div>
        <span><%=title%></span>
      </a>
    </h2>
  </div>
  <div class="abstract">
    <p><%=text%></p>
  </div>
</div>
*/});

// -----------------------------------------------------------------------------

card1 = _.template(card1)
card2 = _.template(card2)

var warp = $('#ydAd');

//广告位id
var adid = 'e73959271a634fa2c00b8258a4ee391c';
adid = '1d627bc7cab65f5651e9e0143776de1b';

//详细参数说明请参照说明文档
var config = yadk.config({
  id: adid,
  nt: '3G',
  /* 该样式是在开发者系统中预先定义好的 */
  rstyle: '首页信息流01-非下载类'
});

//如果android和ios是两个广告位，也可以像下面这么写
//
// yadk.config({
//   andAdID: androidID,
//   iosAdID: iosID,
//   nt: '3G',
//   rstyle: '信息流'
// });

yadk.fetch(function (data) {
  //如果没有广告商投指定样式的广告，
  //那么系统会返回其他样式的广告。
  //媒体在展示的广告的时候，可以根据
  //返回广告的styleName字段判断广告样式是否是所请求的样式
  if(data.styleName !== config.rstyle) {
    return;
  }

  if (data.title && data.text){
    if (data.mainimage) {
      warp.append(card2(data));
    }
    else {
      warp.append(card1(data));
    }
    //广告展示出来（用户能看到才算展示）的时候调用
    //用于通知广告系统该资源展示一次
    //不调用，则广告展示次数不会变化
    yadk.showed(data.imptracker);
  }
});
