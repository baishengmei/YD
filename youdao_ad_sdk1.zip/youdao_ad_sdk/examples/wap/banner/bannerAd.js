function genYdBannerAd(options) {
    var tpl =
      '<div style="{0}">' +
        '<a href="{1}" target="_blank">' +
          '<img src="{2}" style="width:100%;height: 100%;" />' +
        '</a>' +
      '</div>';
    var css = "position: fixed; width: 100%; max-height: 60px; z-index: 999999; ";
    css += options.isBottom ? "bottom: 0;" : "top: 0;";

    var cfg = {
      nt: '3G'
    };
    for(var k in options) {
      cfg[k] = options[k];
    }

    yadk.config(cfg);

    yadk.fetch(function (data) {
      var html = yadk.formatString(tpl, css, data.clktracker, data.mainimage || data.iconimage);

      var div = document.createElement('div');
      div.innerHTML = html;
      document.body.appendChild(div.childNodes[0]);
      div = null;

      yadk.showed(data.imptracker);
    });

  }


  genYdBannerAd({
    id: '1d627bc7cab65f5651e9e0143776de1b',
    //底部banner，顶部banner => isBottom: false
    isBottom: true
  });