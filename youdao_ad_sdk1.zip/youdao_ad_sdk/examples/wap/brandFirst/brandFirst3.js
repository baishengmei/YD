function heredoc(fn) {
    return fn.toString()
        .replace(/^[^\/]+\/\*\s*/,'')
        .replace(/\*\/[^\/]+$/,'');
}

var card1 = heredoc(function (){/*
<div class="card" style="display: inline-block;">
  <i class="card-flag">有道广告</i>
  <div class="cardtitle">
    <h2>
      <a href="<%=clktracker%>">
        <span><%=title%></span>
      </a>
    </h2>
  </div>
  <div class="abstract">
    <p><%=text%></p>
  </div>
</div>
*/});

var card2 = heredoc(function (){/*
<div class="card" style="display: inline-block;">
  <i class="card-flag">有道广告</i>
  <div class="cardtitle">
    <span class="bigpic">
      <a href="<%=clktracker%>">
        <i style="height:242px"></i>
        <img src="<%=mainimage%>">
      </a>
    </span>
    <h2>
      <a href="<%=clktracker%>">
        <div class="title-mask"></div>
        <span><%=title%></span>
      </a>
    </h2>
  </div>
  <div class="abstract">
    <p><%=text%></p>
  </div>
</div>
*/});

// -----------------------------------------------------------------------------

card1 = _.template(card1)
card2 = _.template(card2)

var warp = $('#ydAd');

//广告位id
var adid = 'c7a2aedcbcc0f6b520967c2f9cfc5be5';

//当前为测试样例，实际参数中不需要传debug和reqUrl两个参数
//详细参数说明请参照说明文档
var config = yadk.config({
  id: adid,
  nt: '3G',
  //优先展示品牌广告，
  //媒体需要先联系运营创建品牌广告位，
  //然后与有道广告后台联系设置与效果广告位的关联关系
  //最后再传参数发起请求才能查看到效果
  brandFirst: 1,
  debug: true,
  reqUrl: 'http://test1.gorgon.youdao.com/gorgon/request.s'
});

yadk.fetch(function (data) {

  console.log('isBrand' in data ? data.isBrand ? '品牌广告' : '效果广告' : '无广告返回');

  if (data.title && data.text){
    if (data.mainimage) {
      warp.append(card2(data));
    }
    else {
      warp.append(card1(data));
    }
    //广告展示出来的时候调用
    //用于通知广告系统该资源展示一次
    //不调用，则广告展示次数不会变化
    yadk.showed(data.imptracker);
  }
});
