var adId = 'c8ade4a820c56ae2dbf7145e20f8d442',
    androidAdID = 'e73959271a634fa2c00b8258a4ee391c',
    iosAdID = '4bc26f67fd8cd7632550bcc90a58e52a',
    udid = 'xeIhZ7SWLp0HLaecifef8a9ZeQswKixi',
    imei = '352681005520144';

describe('yadk.config', 'SDK 普通配置', function (tc) {

    var style = '信息流',
        magic_no = 10,
        config,
        status;

    var ua = navigator.userAgent;
    var isAndroid = /android/i.test(ua);
    var isIOS = /iphone|ipad|ipod/i.test(ua);

    config = yadk.config({
        id: adId,
        andAdID: androidAdID,
        iosAdID: iosAdID,
        imei: imei,
        udid: udid,
        rstyle: style,
        MAGIC_NO: magic_no
    });

    if ( isAndroid ) {
        status = androidAdID === config.id && ( 'imei' in config ) && imei === config.imei && udid === config.udid;
    } else if ( isIOS ) {
        status = iosAdID === config.id && (!('imei' in config)) && udid === config.udid;
    } else {
        status = adId === config.id && (!('imei' in config)) && udid === config.udid;
    }

    status = status && style == config.rstyle && magic_no == config.MAGIC_NO ? 'success' : 'error';
    tc.updateStatus(status);
    tc.append('<p>输出：' + tc.code(config || {}) + '</p>');

    for(var k in config) {
        delete config[k];
    }

    yadk.config({
        id: adId,
        udid: udid
    });

});

describe('yadk.config', '品牌广告优先配置', function (tc) {

    var config = yadk.config({
        id: adId,
        brandFirst: 1
    });

    var status = 0 == config.MAGIC_NO ? 'success' : 'error';
    tc.updateStatus(status);
    tc.append('<p>输出：' + tc.code(config || {}) + '</p>');

    for(var k in config) {
        delete config[k];
    }

    yadk.config({
        id: adId,
        udid: udid
    });

});

describe('yadk.config', 'SDK 网络类型配置', function (tc) {

    var nt = '3G',
        ct = 3,
        dct = 12,
        config;

    config = yadk.config({
        nt: nt
    });

    var status = ct === config.ct && dct === config.dct ? 'success' : 'error';
    tc.updateStatus(status);
    tc.append('<p>输出：' + tc.code(config || {}) + '</p>');

    nt = '4G';
    ct = 3;
    dct = 13;

    yadk.config({
        nt: nt
    });

    var status1 = ct === config.ct && dct === config.dct ? 'success' : 'error';
    status = status === 'success' ? status1 : 'error';
    tc.updateStatus(status);
    tc.append('<p>输出：' + tc.code(config || {}) + '</p>');

    nt = 'UNKNOWN';
    ct = 0;
    dct = undefined;

    yadk.config({
        nt: nt
    });

    var status3 = ct === config.ct && dct === config.dct ? 'success' : 'error';
    status = status === 'success' ? status3 : 'error';
    tc.updateStatus(status);
    tc.append('<p>输出：' + tc.code(config || {}) + '</p>');

    nt = 'WIFI';
    ct = 2;

    yadk.config({
        nt: nt
    });

    var status2 = ct === config.ct && dct === config.dct ? 'success' : 'error';
    status = status === 'success' ? status2 : 'error';
    tc.updateStatus(status);
    tc.append('<p>输出：' + tc.code(config || {}) + '</p>');
});

describe('yadk.fetch', '取一个广告数据', function (tc) {
    tc.append('<p>示例：<pre>yadk.fetch(function (data) {...})</pre></p>')
    yadk.fetch(function (data) {
        var status = data.imptracker ? 'success' : 'error';
        tc.updateStatus(status);
        tc.append('<p>输出：' + tc.code(data || {}) + '</p>')
    });
});

describe('yadk.fetch', '取多个广告数据', function (tc) {
    tc.append('<p>示例：<pre>yadk.fetch(2, function (data) {...})</pre></p>')
    yadk.fetch(2, function (data) {
        var status = data.length ? 'success' : 'error';
        tc.updateStatus(status);
        tc.append('<p>输出：' + tc.code(data || {}) + '</p>')
    });
});

describe('指定样式 & yadk.fetch', '获取指定样式广告的 SDK 配置', function (tc) {

    var config;

    config = yadk.config({
        rstyle: '网易荐新闻广告位测试网易荐新闻广告位测试样式_c8ade4a820c56ae2dbf7145e20f8d442'
    });

    yadk.fetch(function (data) {
        var status = data.imptracker && data.styleName == config.rstyle ? 'success' : 'error';
        tc.updateStatus(status);
        tc.append('<p>输出：' + tc.code('rstyle config: ') + tc.code(config || {}) + '</p>');

        if ( status === 'success' ) {
            test2();
        }
    });

    function test2() {
        delete config.rstyle;

        yadk.config({
            MAGIC_NO: 1
        });

        yadk.fetch(function (data) {
            var status = data.imptracker ? 'success' : 'error';
            tc.updateStatus(status);
            tc.append('<p>输出：' + tc.code('MAGIC_NO config: ') + tc.code(config || {}) + '</p>')

            delete config.MAGIC_NO;
        });
    }
});

describe('yadk.showed', '展示成功后, 通知各服务', function (tc) {

    yadk.fetch(function (data) {
        var status = data.imptracker ? 'success' : 'error';
        tc.updateStatus(status);
        //yadk.showed(data && data.imptracker)
        tc.append('<p>输出：' + tc.code((data && data.imptracker) || {}) + '</p>')
    });
});

describe('yadk.downloadStarted', '开始下载, 通知下载统计服务', function (tc) {
    var config = yadk.config({}),
        func = arguments.callee;
    if(config.rstyle != undefined || config.MAGIC_NO != undefined) {
        setTimeout(function() {
            func.call(null, tc);
        }, 1000);
        return;
    }

    // yadk.config({
    //     rstyle: '下载类'
    // });

    yadk.fetch(function (data) {
        var status = data.imptracker ? 'success' : 'error';
        tc.updateStatus(status);

        if(status === 'error') {
            return;
        }

        var dl_params = {
          variantId: data.creativeid,
          pkgName: 'test.pkg.name',
          appVersion: '1.0.0',
          appName: '测试app'
        };


        yadk.downloadStarted(dl_params, function(status) {
            if(status === 'success') {
                tc.append('<p>参数：' + tc.code('config') + tc.code((config) || {}) + '</p>')
                tc.append('<p>参数：' + tc.code('download params') + tc.code((dl_params) || {}) + '</p>')
            } else {
                tc.updateStatus('error');
                tc.append('<p>参数：' + tc.code('config') + tc.code((config) || {}) + '</p>')
                tc.append('<p>参数：' + tc.code('download params') + tc.code((dl_params) || {}) + '</p>')
            }
        });
        delete config.rstyle;
    });
});

describe('yadk.downloadEnded', '下载成功后, 通知下载统计服务', function (tc) {
    var config = yadk.config({}),
        func = arguments.callee;
    if(config.rstyle != undefined || config.MAGIC_NO != undefined) {
        setTimeout(function() {
            func.call(null, tc);
        }, 1000);
        return;
    }

    // yadk.config({
    //     rstyle: '下载类'
    // });

    yadk.fetch(function (data) {
        var status = data.imptracker ? 'success' : 'error';
        tc.updateStatus(status);

        if(status === 'error') {
            return;
        }

        var dl_params = {
          variantId: data.creativeid,
          pkgName: 'test.pkg.name',
          appVersion: '1.0.0',
          appName: '测试app'
        };

        yadk.downloadEnded(dl_params, function(status) {
            if(status === 'success') {
                tc.append('<p>参数：' + tc.code('config') + tc.code((config) || {}) + '</p>')
                tc.append('<p>参数：' + tc.code('download params') + tc.code((dl_params) || {}) + '</p>')
            } else {
                tc.updateStatus('error');
                tc.append('<p>参数：' + tc.code('config') + tc.code((config) || {}) + '</p>')
                tc.append('<p>参数：' + tc.code('download params') + tc.code((dl_params) || {}) + '</p>')
            }
        });

    });
});

describe('yadk.jsonp', '单个 jsonp，无 data', function (tc) {
    var params = {
        url: 'http://dingzq.iyoudao.net/apis/yad-ajax.php'
    }

    // tc.append('<p>输入：' + tc.code(params) + '</p>')

    yadk.jsonp(_.extend({}, params, {
        complete: function (res, status, data) {
            tc.updateStatus(status)
            tc.append('<p>输出：' + tc.code(data || {}) + '</p>')
            tc.append('<p>参数：' + tc.code(res) + '</p>')
        }
    }))
});

describe('yadk.jsonp', '单个 jsonp, 有 data', function (tc) {
    var params = {
        url: 'http://dingzq.iyoudao.net/apis/yad-ajax.php'
    }

    // tc.append('<p>输入：' + tc.code(params) + '</p>')

    yadk.jsonp(_.extend({}, params, {
        data: {content: '00000'},
        complete: function (res, status, data) {
            tc.updateStatus(status)
            tc.append('<p>输出：' + tc.code(data || {}) + '</p>')
            tc.append('<p>参数：' + tc.code(res) + '</p>')
        }
    }))
});

describe('yadk.jsonp', '同时发送多个 jsonp', function (tc) {
    var params = {
        url: 'http://dingzq.iyoudao.net/apis/yad-ajax.php'
    }

    // tc.append('<p>输入：' + tc.code(params) + '</p>')

    yadk.jsonp(_.extend({}, params, {
        data: {content: '网易有道'},
        complete: function (res, status, data) {
            tc.updateStatus(status)
            tc.append('<p>输出：' + tc.code(data || {}) + '</p>')
            tc.append('<p>参数：' + tc.code(res) + '</p>')
        }
    }))

    yadk.jsonp(_.extend({}, params, {
        data: {content: '22222'},
        complete: function (res, status, data) {
            tc.updateStatus(status)
            tc.append('<p>输出：' + tc.code(data || {}) + '</p>')
            tc.append('<p>参数：' + tc.code(res) + '</p>')
        }
    }))

    yadk.jsonp(_.extend({}, params, {
        data: {content: '33333'},
        complete: function (res, status, data) {
            tc.updateStatus(status)
            tc.append('<p>输出：' + tc.code(data || {}) + '</p>')
            tc.append('<p>参数：' + tc.code(res) + '</p>')
        }
    }))
});

/* ie6下的timeout不work */
describe('yadk.jsonp', '超时测试 timeout = 10ms', function (tc) {
    var params = {
        url: 'http://dingzq.iyoudao.net/apis/yad-ajax.php'
    }
    var time = new Date().getTime();
    yadk.jsonp(_.extend({
        timeout: 10
    }, params, {
        complete: function (res, status, data) {
            tc.updateStatus(status)
            tc.append('<p>请求时间:' + (new Date().getTime() - time) + 'ms</p>')
            tc.append('<p>输出：' + tc.code(data || {}) + '</p>')
            tc.append('<p>参数：' + tc.code(res) + '</p>')
        }
    }))
});

describe('yadk.jsonp', 'pageCache = true', function (tc) {
    var params = {
        pageCache: true,
        url: 'http://dingzq.iyoudao.net/apis/yad-ajax.php',
        data: {content: 'pagecache is true'}
    }

    var ts1 = +new Date;
    yadk.jsonp(_.extend({}, params, {
        complete: function (res, status, data) {
            tc.updateStatus(status)
            tc.append('<p>输出：' + (+new Date - ts1) + 'ms, ' + tc.code(data || {}) + '</p>')
            test2()
        }
    }))

    function test2 () {
        var ts2 = +new Date;
        yadk.jsonp(_.extend({}, params, {
            complete: function (res, status, data) {
                tc.updateStatus(status)
                tc.append('<p>输出：' + (+new Date - ts2) + 'ms, ' + tc.code(data || {}) + '</p>')
                test3()
            }
        }))
    }

    function test3() {
        var ts3 = +new Date;
        yadk.jsonp(_.extend({}, params, {
            complete: function (res, status, data) {
                tc.updateStatus(status)
                tc.append('<p>输出：' + (+new Date - ts3) + 'ms, ' + tc.code(data || {}) + '</p>')
                test4()
            }
        }))
    }
    function test4() {
        var ts3 = +new Date;
        yadk.jsonp(_.extend({}, params, {
            complete: function (res, status, data) {
                tc.updateStatus(status)
                tc.append('<p>输出：' + (+new Date - ts3) + 'ms, ' + tc.code(data || {}) + '</p>')
                test5()
            }
        }))
    }
    function test5() {
        var ts3 = +new Date;
        yadk.jsonp(_.extend({}, params, {
            complete: function (res, status, data) {
                tc.updateStatus(status)
                tc.append('<p>输出：' + (+new Date - ts3) + 'ms, ' + tc.code(data || {}) + '</p>')
            }
        }))
    }
});